package arvores;

public class Atividade{
	public static void main(String[] args){
		int[] lista = {1, 2, 3, 4, 5, 6};
		TreeList arvore = constroiLista(lista, 0, lista.length, lista.length/2);

		System.out.println(lista.length);
		
		System.out.println("arvore:");
		
		System.out.println(arvore);
		
	}

	public static TreeList constroiLista(int[] lista, int inf, int sup, int root){
		TreeList tree = new TreeList();
		tree.root = constroiNo(root);
		tree.root.left = constroiLista(lista, inf, sup/2, meio(lista, inf, sup));		
		tree.root.right = constroiLista(lista, inf*2, sup);		
		return tree;
	}

	public static int meio(int[] lista, int inf, int sup){
		return lista[(inf+sup)/2];		
	}
	
	public static TreeNode constroiNo(int no){
		TreeNode node = new TreeNode(no);		
		return node;
	}
	
}